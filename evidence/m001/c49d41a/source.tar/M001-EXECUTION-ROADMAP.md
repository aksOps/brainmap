# M001 Goal-Execution Roadmap

Status: Active execution guide  
Source of truth: `M001-BRAINMAP-READINESS.md`  
Target: A single-user, completely local decision engine for individual developers  
Reader: A fresh implementation agent with repository access but no prior conversation context  
Post-read action: Continue M001 from the current repository state, prove each acceptance criterion, and stop only when the integrated release and dogfood requirements are genuinely satisfied.

This document turns the M001 product specification into an ordered execution plan. It does not replace the specification. When this roadmap and `M001-BRAINMAP-READINESS.md` differ, the readiness specification wins.

## Copy-paste master goal prompt

```text
Execute M001, the Trusted Local Decision Engine milestone, in this repository.

Read AGENTS.md, M001-BRAINMAP-READINESS.md, and M001-EXECUTION-ROADMAP.md completely before changing code. Continue from the current git state; preserve existing user changes and inspect prior commits before repeating work. Follow milestones M1 through M8 in order, using the roadmap's prerequisites, deliverables, verification commands, and evidence rules.

The product is a completely local decision engine for one developer. Markdown is canonical and SQLite is only a rebuildable compiled index. Keep gate evaluation deterministic, bounded, fast, and offline. Never add an LLM, AgentMemory, embedding generation, an external embedding provider, a runtime model download, a runtime model load, or a network call to the gate hot path. Preserve wikilinks and never persist secrets. Learning must use reviewable update packets with preview and explicit approval. Every schema change needs tests, every gate behavior change needs eval coverage, every installer needs dry-run and backup behavior, and every import/export path needs checksum validation.

Use rtk before shell commands in this workspace. Use test-driven development for behavioral changes. Make narrow checkpoint commits only after the milestone's targeted tests pass. Record evidence in M001-EXECUTION-ROADMAP.md as work is verified. Do not check an acceptance criterion merely because code exists or a narrower test passed: record the exact commit, command, result, and retained artifact that prove it. Do not declare the goal complete until every AC is checked, FIA-1 through FIA-8 pass against locked optimized binaries on a clean local machine, the required 1–2 week shadow-mode dogfood interval has completed, final security/package/scale checks pass, and the worktree is clean.

If an acceptance criterion cannot be proven, leave it unchecked, document the concrete gap, and continue with the next safe action. Do not weaken tests, thresholds, local-only constraints, or product claims to obtain a pass.
```

## Non-negotiable execution constraints

- Brainmap is a decision engine, not an information engine or general RAG system.
- Markdown is canonical. SQLite and embeddings are rebuildable products.
- Gate evaluation must contain no network, LLM, AgentMemory, embedding generation, external embedding-provider call, runtime download, or runtime model load.
- Candidate retrieval and scoring must be explicitly bounded and deterministic.
- The default embedding target remains the embedded `minishlab/potion-base-8M` pack outside the hot path.
- Free prose is context, not executable behavior. Only strictly validated structured Markdown fields or deterministic markers may compile into rules.
- Learning produces draft update packets. Preview and explicit user approval are required before activation.
- Project learning defaults to the narrowest safe scope. Global promotion is explicit.
- Relevance, scope, decision type, and option compatibility are resolved before policy or correction priority.
- Preserve wikilinks and never persist secrets in notes, ledgers, packets, exports, diagnostics, search, or web output.
- Every schema change requires tests. Every gate behavior change requires eval coverage.
- Every installer keeps dry-run, backup, idempotency, and unmanaged-file protection.
- Every import/export/restore route keeps checksum, schema, portability, and traversal validation.
- Concurrency and fault proof must use multiple processes where the specification requires it; thread-only tests are insufficient.
- Linux-family systems are the primary release target. Supported behavior must remain covered on macOS and Windows in CI.
- The supported envelope is 1,000–5,000 curated Markdown notes. Do not broaden the claim without evidence.
- Use `rtk` before shell commands in this workspace.

## How to use this roadmap

1. Refresh the status snapshot before starting. Run `rtk git status --short`, `rtk git log --oneline -10`, and the most relevant targeted tests.
2. Work on the earliest incomplete milestone whose prerequisites are satisfied.
3. Start each behavior change with a failing interface, eval, integration, concurrency, or fault test.
4. Keep the public decision-engine seam authoritative. CLI, MCP, stdio, and host adapters must not implement independent decision semantics.
5. Complete the milestone's targeted verification before making its checkpoint commit.
6. Record evidence using the format in this document. A code diff is implementation evidence, not acceptance proof by itself.
7. Leave all acceptance checkboxes open until current evidence proves the criterion exactly as written.
8. Re-run the full release gate in M8 even if an earlier milestone passed it.

### Status vocabulary

- **Implemented candidate:** Relevant code or tests exist, but the full criterion has not been proven at the current commit.
- **Targeted verified:** The milestone's focused test passed at a named commit.
- **Integrated verified:** The behavior passed through the optimized release binary in an FIA drill.
- **Dogfood verified:** The required real-use observation interval and thresholds passed.
- **Complete:** All mapped ACs have current evidence and the milestone completion checkbox may be checked.

## Current repository status snapshot

Snapshot date: 2026-07-10. Refresh this section before relying on it.

| Checkpoint | Known implementation evidence | Acceptance status |
| --- | --- | --- |
| `a584b1c` — evaluation baseline | Added the M001 readiness specification, source/probe eval fixture support, generalization cases, and initial symmetric matching coverage. | Supporting evidence for M1; no final AC is considered complete solely from this commit. |
| `5771514` — scoped engine schema | Added the public decision request/result seam, schema v3 fields, scope propagation, and caller plumbing. | Implemented candidate for M2. |
| `62ba6a4` — scoped learned decisions | Added scope-aware resolution, paraphrase behavior, option/conflict handling, confidence metadata, and negative matching coverage. | Implemented candidate for M3. |
| `816689d` — policy learning loop | Added structured executable policies, onboarding, richer ledgers, structured feedback, preview/approval, and documentation. Earlier conversation evidence reported a passing 82-test suite and clean Clippy at this development checkpoint. | Targeted historical evidence for parts of M4 and M5; rerun at current HEAD before checking ACs. |
| `2a908b8` — local-engine hardening | Added the deep implementation module, expanded MCP/host diagnostics, process concurrency tests, restore staging/fault tests, web hardening, patched `crossbeam-epoch`, SBOM and performance artifacts, and release documentation. | Historical implementation checkpoint for M2, M6, and M7; superseded by the current `d93ea7a` qualification row below. |
| `5c42a5c` through `d5460d3` — final hardening | Hardened policy learning, bounded actual-rule matching, transactional recovery, release qualification, and path-safe evidence generation in scoped commits. | Current implementation for M3–M7. |
| `d93ea7a` — stable M1–M7 code candidate | Passed the complete locked test/lint/build/security/package qualification plus release-binary eval, 1k/5k benchmarks, export/restore equivalence, and all restore fault phases. Raw JSON is retained under `evidence/m001/d93ea7a/`. | M1–M7 targeted verified. This is not M8 integrated, real-host, or dogfood proof. |

The source tree currently contains focused tests for decision matching, policy retirement, onboarding, host doctor behavior, process concurrency, serialized update application, export/restore behavioral equivalence, staged restore fault injection, loopback web serving, request bounds, secret filtering, and aggregate shadow metrics. Their presence is useful implementation evidence, but test presence is not the same as a current passing result.

## Acceptance ownership map

This map assigns each criterion to one primary milestone so nothing is lost. Earlier milestones may provide supporting evidence.

| Primary milestone | Acceptance criteria owned |
| --- | --- |
| M1 — Evaluation baseline | Test-contract foundation for AC-FUN-001 through AC-FUN-004; final proof remains owned by M3. |
| M2 — Decision-engine interface and schema v4 | Supporting architecture proof for AC-FUN-013, AC-FUN-014, AC-PERF-001, and AC-PERF-002; final behavioral/performance proof remains in M3/M7. |
| M3 — Scoped matcher and confidence | AC-FUN-001 through AC-FUN-015. |
| M4 — Executable policy compiler | AC-POL-001 through AC-POL-007. |
| M5 — Onboarding and learning workflow | AC-LRN-001 through AC-LRN-010. |
| M6 — Host adapters and diagnostics | AC-INT-001 through AC-INT-009. |
| M7 — Durability, security, and release proof | AC-DUR-001 through AC-DUR-010; AC-SEC-001 through AC-SEC-008; AC-PERF-001 through AC-PERF-006; AC-REL-001 through AC-REL-008; supporting work for AC-REL-011. |
| M8 — Integrated qualification and release | FIA-1 through FIA-8; AC-REL-009 through AC-REL-012; final current proof for every AC from M3 through M7. |

## Dependency and critical path

```text
M1 evaluation contract
  -> M2 one engine seam + schema v4
    -> M3 scoped matcher/confidence
      -> M4 executable policies
        -> M5 onboarding/feedback/approval
          -> M6 stdio + one real host loop
            -> M7 concurrency/recovery/security/performance/release hardening
              -> M8 clean-machine FIAs -> 1–2 week shadow dogfood -> final clean verification
```

The critical path is M1 → M2 → M3 → M4 → M5 → M6 → M7 → M8. Security scanning, CI repair, docs, and benchmark harness work may proceed alongside earlier implementation only when they do not validate behavior built on an unstable engine seam. The dogfood clock must not start until M1–M7 are targeted-verified and the release candidate is stable; otherwise material behavior changes reset the observation interval.

---

## M1 — Evaluation baseline

Objective: Turn every known matcher failure into an executable contract that distinguishes a learned source situation from later probe situations.

Current status: **Targeted verified at `d93ea7a`.** The current release-binary eval passes all 238 cases after the final matcher changes; raw output is retained in `evidence/m001/d93ea7a/eval.json`.

### Prerequisites

- Read the full functional acceptance section in the readiness specification.
- Capture the current eval baseline without weakening expected outcomes.
- Identify the fixture format, release-binary eval entry point, and public `evaluate` seam.

### Concrete deliverables

- Eval fixtures can define different learned-source and probe situations.
- Exact recall cases cover learned choices and corrections.
- Curated paraphrase cases cover at least five meaningful variants per representative learned decision.
- A negative suite contains at least 100 cross-domain, cross-operation, cross-project, and option-collision cases.
- Option-membership and precedence cases exercise missing options, reordering, ambiguity, and correction priority.
- Every future gate behavior regression can be reproduced through the public decision interface or eval CLI.
- A retained baseline report records case counts, pass/fail counts, recall, collisions, and observed gaps.

### Acceptance mapping

- Supporting contract for **AC-FUN-001** exact learned-decision recall.
- Supporting contract for **AC-FUN-002** supported-paraphrase recall.
- Supporting contract for **AC-FUN-003** at least 100 negative cases with zero learned-rule applications.
- Supporting contract for **AC-FUN-004** selected-option membership.
- M3 owns final completion of these criteria after the matcher implementation passes them.

### Verification and required evidence

```bash
rtk cargo test --locked -p brainmap-cli eval
rtk cargo test --locked -p brainmap-cli decision_engine
rtk cargo run --locked -p brainmap-cli --bin brainmap -- eval \
  --vault /tmp/brainmap-m001-eval \
  --suite fixtures/decision-bench
```

Retain:

- The eval JSON/report with total exact, paraphrase, and negative case counts.
- The commit hash containing the fixtures and fixture parser.
- Test output showing source/probe separation is exercised.
- A note confirming no expectation, threshold, or negative case was weakened to obtain a pass.

- [x] **M1 complete:** The full regression contract exists, runs through the public behavior surface, and has current passing evidence. This checkbox does not complete AC-FUN-001 through AC-FUN-004; M3 must prove those outcomes.

---

## M2 — Decision-engine interface and schema v4

Objective: Make one small decision-engine interface authoritative and compile all executable decision data into a deterministic schema v4 index. Schema v4 supersedes the original v3 plan with bounded choice-keyed postings.

Current status: **Targeted verified at `d93ea7a`.** Schema v4 uses bounded actual-rule term postings, all callers use the authoritative decision interface, deterministic rebuild/caller compatibility tests pass, and the full all-feature Clippy gate is clean.

### Prerequisites

- M1 regression contract is runnable.
- Existing CLI JSON compatibility requirements are inventoried.
- Schema v2 export/rebuild/restore compatibility is understood before changing compiled storage.

### Concrete deliverables

- One public `evaluate(request) -> result` interface owns safety precedence, policy evaluation, matching, conflict resolution, confidence, restrictions, and SQLite access.
- Request data includes situation, intent, options, proposed action, risk, reversibility, decision type, and scope.
- Result data includes outcome, selected option, causal rule ID, rule scope, match kind, match score, calibrated confidence, causal restrictions, and applied policies.
- CLI, MCP, generic stdio, host translation, eval, and benchmarks call the same interface.
- Schema v4 stores rule ID, decision type, scope, normalized choice/options, evidence, status, token counts, and bounded match-relevant posting keys.
- Rebuild is deterministic from Markdown, rejects invalid control policy state, and treats SQLite as disposable.
- Export manifests identify the current compiled schema; restore rebuilds rather than trusting stale compiled state.
- Schema migration/rebuild and caller-compatibility tests exist.

### Acceptance mapping

- Supports **AC-FUN-013** explainability metadata and causal restrictions.
- Supports **AC-FUN-014** deterministic repeated results.
- Supports **AC-PERF-001** one enforceable local-only hot path.
- Supports **AC-PERF-002** one bounded retrieval implementation.
- Final behavioral proof remains in M3 and performance proof in M7.

### Verification and required evidence

```bash
rtk cargo test --locked -p brainmap-cli schema_contains_compiled_decision_rules_table
rtk cargo test --locked -p brainmap-cli exports_declare_current_compiled_schema
rtk cargo test --locked -p brainmap-cli decision_engine
rtk cargo test --locked -p brainmap-cli mcp
rtk cargo test --locked -p brainmap-cli harness
rtk cargo clippy --locked --all-targets --all-features -- -D warnings
```

Also inspect call sites and record evidence that caller modules translate inputs/outputs but do not independently choose outcomes. Retain schema output from a clean rebuild and two byte-for-byte-equivalent substantive responses from identical state/request runs.

- [x] **M2 complete:** One authoritative interface is used by all callers, schema v4 rebuilds deterministically from Markdown, legacy v3 is rejected for rebuild, compatibility is intentional, and targeted tests/Clippy pass at the checkpoint commit.

---

## M3 — Scoped matcher and calibrated confidence

Objective: Apply exact and supported paraphrased learned decisions narrowly, never personalize by option order, and surface uncertainty honestly.

Current status: **Targeted verified at `d93ea7a`.** The final bounded matcher ranks real rules rather than synthetic aggregate choices; the retained eval records 6/6 exact, 10/10 paraphrase, 207/207 negative-specificity cases, ambiguity detection, and zero safety or metadata mismatches.

### Prerequisites

- M1 fixture contract passes through the M2 interface.
- Schema v4 contains scope, decision type, status, options, evidence, stable rule IDs, and bounded choice-keyed postings.
- Thresholds are selected from measured eval results, not intuition.

### Concrete deliverables

- Exact matching filters by active status, compatible scope, decision type, and current options.
- Fuzzy matching uses bounded deterministic bidirectional lexical similarity plus operation/domain anchors.
- Project-scoped decisions never leak to another project or become global without explicit promotion.
- Relevance and option compatibility sort candidates before classification/correction priority.
- A documented minimum score and best-candidate margin control application versus ambiguity.
- Equal or close conflicting candidates return a focused question and identify the conflict.
- A learned choice absent from current options asks only on exact/high-confidence applicability; weak option mismatch becomes no match.
- Generic unlearned low-risk decisions ask or follow a named executable policy; they never select the first option merely because it is first.
- Confidence derives from match kind, score, margin, evidence, and scope compatibility; minimum-threshold fuzzy matches cannot report high confidence.
- Result metadata exposes the causal rule, scope, match kind, score, confidence, restrictions, and causally applied policies.
- Property/eval coverage proves option membership, option-order invariance, determinism, scope containment, bounded candidates, and safety non-proceed.

### Acceptance criteria

- [x] **AC-FUN-001:** Exact learned-decision recall is 100% across the evaluation suite.
- [x] **AC-FUN-002:** Curated supported-paraphrase recall is at least 95%.
- [x] **AC-FUN-003:** At least 100 cross-domain, cross-operation, cross-project, and option-collision negatives produce zero learned-rule applications.
- [x] **AC-FUN-004:** Every selected option is a current request option or explicitly declared policy default.
- [x] **AC-FUN-005:** Reordering request options does not alter a learned or policy-driven decision.
- [x] **AC-FUN-006:** Unlearned low-risk reversible decisions do not personalize the first option.
- [x] **AC-FUN-007:** Missing learned choices ask only for exact/high-confidence applicable situations; weak matches act as no match.
- [x] **AC-FUN-008:** Close candidates without sufficient margin return explicit ambiguity and a focused question.
- [x] **AC-FUN-009:** Classification priority runs only after relevance, scope, and option compatibility.
- [x] **AC-FUN-010:** Correction priority cannot defeat a more relevant rule from another scope or decision type.
- [x] **AC-FUN-011:** Confidence is evidence-derived rather than a fixed learned-rule constant.
- [x] **AC-FUN-012:** A minimum-threshold fuzzy match cannot report high confidence.
- [x] **AC-FUN-013:** Results expose rule ID, scope, match kind, match score, confidence, and causal restrictions.
- [x] **AC-FUN-014:** Identical compiled state and request produce identical substantive results.
- [x] **AC-FUN-015:** High-risk irreversible, secret-like, and hard-no suites contain zero false proceeds.

### Verification and required evidence

```bash
rtk cargo test --locked -p brainmap-cli decision_engine_impl
rtk cargo test --locked -p brainmap-cli index
rtk cargo run --locked -p brainmap-cli --bin brainmap -- eval \
  --vault /tmp/brainmap-m001-matcher \
  --suite fixtures/decision-bench
rtk cargo test --locked -p brainmap-cli --test smoke
```

Retain the machine-readable eval output. It must state exact and paraphrase denominators, negative-case count, collisions, option-membership failures, ambiguity results, and safety false-proceed count. Record the selected thresholds and their observed recall/collision tradeoff. Run the same request repeatedly and with permuted options; retain normalized result comparisons that omit only intentionally variable IDs/timestamps.

- [x] **M3 complete:** AC-FUN-001 through AC-FUN-015 are individually checked with current evidence at the checkpoint commit.

---

## M4 — Executable structured Markdown policies

Objective: Compile strictly validated structured Markdown into causal decision behavior while keeping prose non-executable and safety rules fail-closed.

Current status: **Targeted verified at `d93ea7a`.** Structured-policy validation, causal application, retirement, prose isolation, and wikilink behavior pass through the current schema/matcher; source and restored policy gate JSON is retained.

### Prerequisites

- M2 schema and rebuild behavior are stable.
- M3 relevance, scope, conflict, and confidence semantics are stable.
- The policy contract distinguishes control policies from non-control rules.

### Concrete deliverables

- A documented, versioned, strict policy marker/schema with stable IDs, scope, decision type, options, choice, status, evidence, and confidence inputs.
- Markdown parsing preserves wikilinks and rejects unknown executable fields.
- Active policies and learned decisions compile into one deterministic rule representation.
- Named safety invariants remain highest-precedence control rules.
- Active valid policy changes an applicable gate decision after rebuild.
- Retired, stale, or contradicted policy does not apply after rebuild.
- Prose edits outside structured fields cannot change executable behavior.
- Invalid control policy stops compilation with its note and field named.
- Invalid non-control policy is excluded with an actionable warning.
- `appliedPolicies` includes only policies that causally changed outcome, selection, restrictions, or required approval.
- Conflicting policies follow M3 relevance/margin rules and surface ambiguity rather than fabricated certainty.

### Acceptance criteria

- [x] **AC-POL-001:** Structured Markdown format is documented, strictly validated, and preserves wikilinks.
- [x] **AC-POL-002:** Adding an active valid policy and rebuilding changes an applicable gate result.
- [x] **AC-POL-003:** Retiring a policy and rebuilding prevents it from applying.
- [x] **AC-POL-004:** Free prose outside structured fields does not silently alter gate behavior.
- [x] **AC-POL-005:** Invalid control policies fail closed with actionable errors.
- [x] **AC-POL-006:** Invalid non-control policies are excluded with actionable warnings.
- [x] **AC-POL-007:** `appliedPolicies` reports only causally influential policies.

### Verification and required evidence

```bash
rtk cargo test --locked -p brainmap-cli structured_markdown_policy_is_causal_and_retirable
rtk cargo test --locked -p brainmap-cli malformed_executable_control_policy_fails_closed
rtk cargo test --locked -p brainmap-cli malformed_non_control_rule_is_excluded_without_disabling_the_index
rtk cargo test --locked -p brainmap-cli index
rtk cargo run --locked -p brainmap-cli --bin brainmap -- eval \
  --vault /tmp/brainmap-m001-policy \
  --suite fixtures/decision-bench
```

Retain before/active/retired gate JSON for the same request, compiler output for both invalid-policy classes, a prose-only mutation comparison, and a wikilink round-trip/check. The active result must name the policy; the retired result must not.

- [x] **M4 complete:** AC-POL-001 through AC-POL-007 are individually checked with current evidence at the checkpoint commit.

---

## M5 — Onboarding and learning workflow

Objective: Let a developer create, review, approve, correct, and reapply scoped behavior without silently activating ambiguous or secret-bearing input.

Current status: **Targeted verified at `d93ea7a`.** The current onboarding, learning, ledger, feedback, correction, approval, idempotency, ambiguity, and secret-handling suites pass; release-binary learned/corrected results survive export and restore.

### Prerequisites

- M3 matching behavior and M4 policy format are stable.
- The ledger schema can replay the original decision context.
- Packet application has a stable ID and schema contract.

### Concrete deliverables

- Interactive onboarding works on a clean vault and asks at least three useful calibration questions.
- A versioned answer-file schema provides deterministic automation.
- Dry-run shows exact proposed notes/packets and performs no filesystem or behavioral mutation.
- Predefined answers map deterministically to scoped executable policies.
- Ambiguous free text remains pending with a focused explanation of missing structure.
- Activation shows the exact policy/update and requires explicit approval.
- Approval writes canonical Markdown, rebuilds the index automatically, and is idempotent.
- Non-dry gate ledger entries retain intent, situation, options, proposed action, risk, reversibility, decision type, scope, outcome, selection/rejection, rule/match metadata, restrictions, and applied policies.
- Structured feedback references a known decision ID and captures explicit chosen/rejected options while preserving the original context and scope.
- Corrections become draft packets, preview accurately, apply once, and affect the next applicable decision without cross-scope leakage.
- Onboarding, ledger, feedback, packet, rendered note, and identifiers reject or redact secret-like material before persistence.

### Acceptance criteria

- [x] **AC-LRN-001:** A clean vault supports complete interactive onboarding.
- [x] **AC-LRN-002:** Onboarding accepts a versioned answer file.
- [x] **AC-LRN-003:** Onboarding dry-run performs no mutation.
- [x] **AC-LRN-004:** Exact policy/update preview is shown before activation.
- [x] **AC-LRN-005:** Predefined calibration answers compile into executable scoped policies.
- [x] **AC-LRN-006:** Ambiguous free-text answers remain pending.
- [x] **AC-LRN-007:** Non-dry gate ledger records complete replay context and decision evidence.
- [x] **AC-LRN-008:** Structured feedback references a decision ID and explicit chosen/rejected options.
- [x] **AC-LRN-009:** Applying a correction changes the next applicable result and is idempotent.
- [x] **AC-LRN-010:** Secret-like onboarding, feedback, ledger, and packet content is rejected or redacted before persistence.

### Verification and required evidence

```bash
rtk cargo test --locked -p brainmap-cli onboarding
rtk cargo test --locked -p brainmap-cli learning
rtk cargo test --locked -p brainmap-cli --test smoke onboarding_answer_file_changes_a_scoped_decision
rtk cargo test --locked -p brainmap-cli --test smoke interactive_onboarding_completes_on_a_clean_vault
rtk cargo test --locked -p brainmap-cli decision_ledger_records_replayable_context
rtk cargo test --locked -p brainmap-cli structured_feedback_preserves_the_original_decision_scope
rtk cargo test --locked -p brainmap-cli corrected_feedback_compiles_explicit_choice_and_rejection
```

Run a release-binary drill in a temporary clean vault: dry-run and hash the tree; apply onboarding; capture the policy preview; make a gate decision; record the action; submit correction; preview; approve; rerun the same and unrelated requests. Retain tree hashes, ledger/packet schema samples with secret-safe synthetic data, gate JSON before/after, and an idempotent second-apply result.

- [x] **M5 complete:** AC-LRN-001 through AC-LRN-010 are individually checked with current evidence at the checkpoint commit.

---

## M6 — Generic stdio, host adapter, MCP, and diagnostics

Objective: Complete the gate/record/correct/preview/approve loop through generic stdio and one honestly advertised coding-agent integration.

Current status: **Targeted verified at `d93ea7a`.** Harness, MCP, installer, golden-payload, doctor, approval, and dynamic-skill tests pass with accurate enforcement labels. A real Codex host run remains deliberately owned by FIA-5 in M8.

### Prerequisites

- M5 learning commands and packet lifecycle are stable.
- The first fully proven host is explicitly selected for M001; Codex is the current implementation candidate.
- Every advertised host event and enforcement claim is inventoried.

### Concrete deliverables

- Generic stdio accepts the complete structured gate request and returns the complete decision result.
- Harness adapters translate host payloads into the same M2 request and translate results without reimplementing semantics.
- At least one coding-agent host completes gate, action recording, structured correction, pending preview, explicit approval, and changed-next-decision flow.
- MCP exposes only allowlisted gate, context, record, feedback, pending-preview, and approved-apply tools; it exposes no shell/general execution tool.
- MCP approved apply requires an explicit boolean approval and rejects omission/false.
- Pre-tool hooks enforce safety/approval decisions only where the host supports enforcement and do not claim to infer unobservable personal choices.
- Every adapter is labeled exactly `enforced`, `best-effort`, or `instruction-only` based on actual host capabilities.
- Integration doctor distinguishes executable, vault, configuration, gate, recording, feedback, approval, and enforcement failures.
- Installer dry-run lists every path/change; mutation backs up changed existing files, remains idempotent, and refuses to overwrite unmanaged owned files.
- Golden payloads cover every advertised host event shape, including invalid/missing fields and user-facing output.

### Acceptance criteria

- [x] **AC-INT-001:** Generic stdio supports the full structured gate request/response contract.
- [x] **AC-INT-002:** One coding-agent adapter completes gate, record, correction, preview, approval, and changed-next-decision.
- [x] **AC-INT-003:** MCP exposes the narrow allowlist and no shell tool.
- [x] **AC-INT-004:** Pre-tool hooks enforce only supported safety/approval behavior.
- [x] **AC-INT-005:** Adapter enforcement labels are accurate.
- [x] **AC-INT-006:** Integration doctor verifies executable, vault, configuration, gate, recording, feedback, and enforcement.
- [x] **AC-INT-007:** Installer dry-run lists every planned change.
- [x] **AC-INT-008:** Installer backs up changes, is idempotent, and protects unmanaged owned files.
- [x] **AC-INT-009:** Golden-payload tests cover every advertised host event shape.

### Verification and required evidence

```bash
rtk cargo test --locked -p brainmap-cli harness
rtk cargo test --locked -p brainmap-cli mcp
rtk cargo test --locked -p brainmap-cli install
rtk cargo test --locked -p brainmap-cli --test smoke codex_integration_doctor_verifies_the_learning_contract
rtk cargo test --locked -p brainmap-cli skill_command_prints_dynamic_build_decision_engine_skill
```

Then use the optimized binaries to run an end-to-end stdio transcript and the chosen host adapter. Retain request/response frames, doctor JSON, installer dry-run output, backup/idempotency evidence, negative approval output, the host's actual enforcement label, and the before/after corrected decision. Compare the tested golden-payload inventory to every host event named in installer/docs.

- [x] **M6 complete:** AC-INT-001 through AC-INT-009 are individually checked with current evidence at the checkpoint commit.

---

## M7 — Durability, security, performance, and automated release proof

Objective: Make the local engine safe under concurrent processes and interrupted recovery, protect local data by default, and prove the supported release envelope.

Current status: **Targeted verified at `d93ea7a`.** The locked all-feature suite, scanners, SBOM, packages, optimized binaries, 1k/5k benchmarks, export/restore equivalence, and all eight restore fault phases pass. CI definitions validate on Linux/macOS/Windows; live remote run IDs are not claimed. Final FIA-8 is rerun after dogfood.

### Prerequisites

- M1–M6 are targeted-verified on a stable candidate commit.
- The canonical/compiled boundary is final enough to test crash recovery.
- No known matcher, schema, or adapter redesign is expected during qualification.

### Substep A — Concurrent canonical state and recovery

Deliverables:

- Collision-resistant IDs remain unique for simultaneous identical requests across processes.
- Atomic writes use unique same-directory temporary files, sync file contents, replace safely, and sync the parent directory where supported.
- JSONL serialization occurs before a process-level append lock; each append is a complete valid line.
- Update application is process-serialized and an already-applied packet cannot activate twice.
- Index rebuild, snapshot, restore, ledger, capture, feedback, and update application use appropriate process-level locks.
- Lock contention is diagnosable; stale state is recoverable without deleting an active lock.
- A 16-process test mixes gate, recording, capture, feedback, index/update traffic and proves unique IDs, valid JSONL, and no lost/truncated canonical notes or packets.
- Restore verifies checksum/schema/paths, writes staging, rebuilds index, checks links, runs gate smoke, and only then swaps the target.
- Failure injection covers every restore phase and proves either the complete old or complete new vault remains active.
- Export/restore comparison proves learned, corrected, and policy-driven behavior is substantively identical.

Acceptance criteria:

- [x] **AC-DUR-001:** Concurrent identical requests cannot generate duplicate IDs.
- [x] **AC-DUR-002:** Atomic writes use unique same-directory temporary files and sync before replacement.
- [x] **AC-DUR-003:** JSONL appends are process-safe and never interleave partial JSON.
- [x] **AC-DUR-004:** Update application is serialized and cannot apply a packet twice.
- [x] **AC-DUR-005:** Index, snapshot, restore, ledger, capture, and update operations use process-level locking.
- [x] **AC-DUR-006:** Stale locks are detectable and safely recoverable.
- [x] **AC-DUR-007:** The 16-process test leaves complete valid state, unique IDs, and no lost records.
- [x] **AC-DUR-008:** Restore validates content, index, links, and gate behavior in staging before replacement.
- [x] **AC-DUR-009:** Every injected restore-phase failure leaves a complete old or new vault active.
- [x] **AC-DUR-010:** Export/restore preserves learned, corrected, and policy-driven behavior exactly.

Verification:

```bash
rtk cargo test --locked -p brainmap-cli util
rtk cargo test --locked -p brainmap-cli --test smoke concurrent_processes_preserve_ledgers_ids_capture_and_feedback
rtk cargo test --locked -p brainmap-cli --test smoke concurrent_update_processes_apply_a_packet_at_most_once
rtk cargo test --locked -p brainmap-cli export
rtk cargo test --locked -p brainmap-cli --test smoke export_restore_preserves_learned_corrected_and_policy_decisions
```

Retain process counts, all generated IDs, JSONL validation counts, packet/canonical file hashes, lock-contention/stale-lock results, every fault-injection phase result, archive checksum verification, and before/after gate comparison.

### Substep B — Security and privacy

Deliverables:

- No unignored vulnerability remains in `cargo audit`; policy suppressions, if any are allowed by the AC, are explicit, narrow, justified, and not used to hide a vulnerability.
- `cargo deny` passes advisories, bans, licenses, and sources.
- `crossbeam-epoch` resolves to a patched version; current candidate is 0.9.20.
- Web serving accepts only loopback hosts by default; remote mode is not claimed.
- Web requests have bounded headers/body where applicable plus read/write timeouts.
- Search and read-only web payloads exclude secret-classified notes and secret-like persisted fields.
- Imports, restores, packets, IDs, and archive paths keep traversal, portability, schema, checksum, and secret validation.
- A current CycloneDX SBOM is generated and retained with the release artifact.

Acceptance criteria:

- [x] **AC-SEC-001:** `cargo audit` reports no unignored vulnerabilities.
- [x] **AC-SEC-002:** `cargo deny check` passes advisories, bans, licenses, and sources.
- [x] **AC-SEC-003:** `crossbeam-epoch` is upgraded to a patched release.
- [x] **AC-SEC-004:** Web UI rejects non-loopback binding by default.
- [x] **AC-SEC-005:** Web requests have bounded size and read/write timeouts.
- [x] **AC-SEC-006:** Read-only web and search cannot expose secret notes.
- [x] **AC-SEC-007:** Import, restore, packets, identifiers, and archive paths retain all safety validation.
- [x] **AC-SEC-008:** A release SBOM is generated and retained.

Verification:

```bash
rtk cargo test --locked -p brainmap-cli web
rtk cargo test --locked -p brainmap-cli learning
rtk cargo test --locked -p brainmap-cli export
rtk cargo audit
rtk cargo deny check
rtk cargo cyclonedx --format json --override-filename brainmap
rtk cargo tree -i crossbeam-epoch
```

Retain complete scanner output, resolved dependency version, SBOM hash/path, non-loopback rejection output, request-limit/timeout results, and synthetic secret-exclusion test output.

### Substep C — Determinism and supported performance envelope

Deliverables:

- Static/test proof that the gate hot path has no prohibited external or model operations and no full-vault scan.
- Candidate query terms, rows per term, and total scored rows have explicit constants and boundary tests.
- Locked optimized binaries benchmark 200 timed calls after warm-up at 1,000 and 5,000 notes.
- Reference host details, binary commit/hash, p50/p95/max gate latency, rebuild duration, candidate bounds, and commands are retained.
- 1,000-note gate p95 is under 10 ms.
- 5,000-note gate p95 is under 25 ms and rebuild is under 1 second.

Acceptance criteria:

- [x] **AC-PERF-001:** Gate has no network, LLM, AgentMemory, embedding generation/provider, runtime download/load, or full-vault scan.
- [x] **AC-PERF-002:** Candidate terms and rows are bounded and tested.
- [x] **AC-PERF-003:** Optimized 1k-note gate is below 10 ms p95 on the reference host.
- [x] **AC-PERF-004:** Optimized 5k-note gate is below 25 ms p95 on the reference host.
- [x] **AC-PERF-005:** Optimized 5k-note index rebuild is below 1 second on the reference host.
- [x] **AC-PERF-006:** Results and host details are recorded as release baselines, not universal guarantees.

Verification:

```bash
rtk cargo build --release --locked --bin brainmap --bin brainmapd
rtk target/release/brainmap bench --vault /tmp/brainmap-scale-1000 --scale 1000
rtk target/release/brainmap bench --vault /tmp/brainmap-scale-5000 --scale 5000
```

Retain raw JSON benchmark output in addition to the human-readable baseline. If matching/index code changes after measurement, rerun both scales.

### Substep D — Automated release gates

Deliverables:

- All test classes pass at the candidate commit.
- Formatting and all-target/all-feature Clippy pass with warnings denied.
- Locked optimized `brainmap` and `brainmapd` builds succeed.
- Cargo and npm package smoke/dry-run checks pass.
- Release-binary checksum/export/restore and 1k/5k scale drills pass.
- CI defines supported Linux, macOS, and Windows jobs.
- User documentation states local single-user scope, enforcement labels, performance envelope, backup procedure, and non-goals.

Acceptance criteria:

- [x] **AC-REL-001:** Unit, interface, integration, adapter, eval, property, concurrency, fault, and smoke tests all pass.
- [x] **AC-REL-002:** Formatting check passes.
- [x] **AC-REL-003:** All-target/all-feature Clippy passes with warnings denied.
- [x] **AC-REL-004:** Locked optimized `brainmap` and `brainmapd` builds pass.
- [x] **AC-REL-005:** Cargo and npm package smoke tests pass.
- [x] **AC-REL-006:** Release-binary export checksum and restore drills pass.
- [x] **AC-REL-007:** Release-binary Linux 1k/5k scale drills pass.
- [x] **AC-REL-008:** CI covers supported Linux, macOS, and Windows behavior.
- Supporting deliverable for **AC-REL-011:** User claims and operational docs are accurate; M8 performs the final review.

Verification:

```bash
rtk cargo fmt --check
rtk cargo clippy --locked --all-targets --all-features -- -D warnings
rtk cargo test --locked --all-targets --all-features
rtk cargo audit
rtk cargo deny check
rtk cargo cyclonedx --format json --override-filename brainmap
rtk cargo build --release --locked --bin brainmap --bin brainmapd
rtk cargo package --locked -p brainmap-cli
rtk npm test --prefix npm/brainmap
rtk npm pack --dry-run ./npm/brainmap
```

Retain complete outputs, artifact hashes, SBOM, package manifests, CI run URLs/IDs when available, release-binary FIA preflight output, and the candidate commit hash.

- [x] **M7 complete:** AC-DUR-001–010, AC-SEC-001–008, AC-PERF-001–006, and AC-REL-001–008 are individually checked with current evidence; release docs are ready for final M8 review.

---

## M8 — Integrated qualification, shadow dogfood, and final release

Objective: Prove the whole product on a clean local machine using optimized locked binaries, observe it in real local decisions for 1–2 weeks, and leave a clean, honestly documented release state.

Current status: **Preflight complete, dogfood not started.** M1–M7 are targeted verified on code candidate `d93ea7a`. A two-source-root rebuild exposed a 32-byte CLI variation caused by source-root-sensitive upstream code generation; deterministic release-build path remapping must be added and verified before selecting the dogfood candidate. No evidence yet proves the required clean-machine FIA sequence, FIA-5 through a real Codex host, or the 1–2 week real-use interval. Synthetic tests or a shortened interval cannot satisfy this milestone.

### Prerequisites

- M1–M7 are complete at one stable release-candidate commit.
- The worktree is clean before qualification begins.
- Locked optimized binaries and checksums are available.
- A clean-machine test location and a real local dogfood vault are identified.
- No material decision, matching, policy, learning, adapter, persistence, or metrics change is planned during dogfood. A material behavior change resets the dogfood clock.

### Substep A — Run all final integrated acceptance drills

Run and retain evidence for every scenario from the readiness specification:

1. **FIA-1 first-run onboarding:** Clean vault; three or more answers; exact preview; approval; automatic rebuild; behavior derived from answers.
2. **FIA-2 learned generalization:** Project formatter decision; exact plus at least five paraphrases; no leak to another ecosystem or database/logging/package-manager decisions.
3. **FIA-3 correction loop:** Non-dry decision ID; structured correction; preview/approval; corrected next result; no relevance/scope priority inversion.
4. **FIA-4 executable Markdown policy:** Add/rebuild/apply; retire/rebuild/no apply; causal `appliedPolicies` only.
5. **FIA-5 host integration:** Installer dry-run; install; healthy doctor; host obeys outcome/selection; action record; correction; approval; changed next host decision.
6. **FIA-6 concurrent local operation:** At least 16 gate/record/capture/feedback processes; valid complete JSONL; unique IDs; no lost/truncated packet or Markdown.
7. **FIA-7 backup and recovery:** Export/checksum/restore; behavior equivalence; injected restore failure leaves complete old or new vault.
8. **FIA-8 release gate:** Format, Clippy, all tests, audit, deny, SBOM, locked builds, package smoke, 1k/5k checks, budgets, and clean worktree.

Use a dated evidence directory or release report that contains commands, exit codes, machine details, binary hashes, sanitized structured outputs, and artifact checksums. Do not retain raw personal prompts in aggregate metrics.

- [ ] FIA-1 passes against the optimized release binary on a clean local machine.
- [ ] FIA-2 passes against the optimized release binary on a clean local machine.
- [ ] FIA-3 passes against the optimized release binary on a clean local machine.
- [ ] FIA-4 passes against the optimized release binary on a clean local machine.
- [ ] FIA-5 passes through the selected real coding-agent adapter.
- [ ] FIA-6 passes with at least 16 operating-system processes.
- [ ] FIA-7 passes, including every injected restore failure phase.
- [ ] FIA-8 passes at the exact release-candidate commit.

### Substep B — Run the required 1–2 week shadow-mode dogfood

Dogfood procedure:

1. Record the release-candidate commit, binary hash, host details, vault backup checksum, start time, planned end time, and selected coding-agent adapter.
2. Keep Brainmap in shadow mode for at least seven full days and preferably fourteen days of normal local development use.
3. Route real structured decisions through the gate and record the actual action against the returned decision ID.
4. Submit corrections through the normal feedback/preview/approval workflow; do not patch metrics manually.
5. Review aggregate metrics at a regular cadence without retaining raw prompts for metric reporting.
6. Investigate every safety false-proceed, privacy/hard-rule violation, or suspected cross-domain learned-rule application immediately.
7. A confirmed safety false-proceed or cross-domain application fails the candidate. Fix it, rerun affected M1–M7 proof, and restart the dogfood interval.
8. At interval end, export and checksum the vault, capture aggregate status, and write a signed/dated qualification summary containing observation duration and incident disposition.

Required aggregate metrics:

- Exact match count/rate.
- Fuzzy match count/rate.
- Gate/action agreement count/rate.
- Correction count/rate.
- False-ask count/rate.
- Confirmed collision count/rate.
- Mean or distribution of match margin.
- Gate p50 and p95 latency.
- Observation start/end and duration.
- Safety false-proceed count.
- Privacy/hard-rule violation count.

Acceptance criteria:

- [ ] **AC-REL-009:** A 1–2 week local shadow run records zero safety false-proceed and zero confirmed cross-domain learned-rule application.
- [ ] **AC-REL-010:** Aggregate metrics contain exact/fuzzy match, agreement, correction, false ask, collision, margin, and latency without raw prompts.

### Substep C — Final documentation and clean verification

- Reconcile documentation with proven behavior. State single-user/local-only scope, chosen adapter and enforcement level, 1k–5k envelope, reference-host metrics, backup/restore procedure, learning approval model, and known non-goals.
- Do not claim remote access, automatic unreviewed learning, every-host enforcement, universal latency, multi-user operation, or arbitrary-prose understanding.
- Re-run all M7 release commands and FIA-8 at the final commit after the dogfood report/docs are added.
- Confirm tracked SBOM/evidence artifacts are intentional and reproducible.
- Confirm `rtk git status --short` produces no output.

Acceptance criteria:

- [ ] **AC-REL-011:** User documentation accurately states supported scope, enforcement levels, performance envelope, backup procedure, and known non-goals.
- [ ] **AC-REL-012:** Final verification leaves the repository worktree clean.
- [ ] Every AC-FUN, AC-POL, AC-LRN, AC-INT, AC-DUR, AC-SEC, AC-PERF, and AC-REL checkbox in this roadmap has current evidence at the final commit.

- [ ] **M8 complete:** FIA-1 through FIA-8 pass, AC-REL-009 through AC-REL-012 pass, every prior criterion has current integrated evidence, the 1–2 week dogfood interval is valid, release claims are bounded, and the final worktree is clean.

---

## Checkpoint commit rules

1. Never mix unrelated cleanup or user changes into an M001 checkpoint.
2. Begin a behavior change with a failing test that demonstrates the acceptance gap.
3. Keep checkpoints narrow enough to bisect. Prefer one commit for the contract and one for the behavior when the change is large.
4. Before committing, run the milestone's targeted tests plus formatting for touched Rust code.
5. Any gate behavior change also runs the decision eval suite.
6. Any schema change also runs clean rebuild, export-manifest, restore, and schema tests.
7. Any installer change also runs dry-run, backup, idempotency, and unmanaged-file tests.
8. Any persistence/concurrency change also runs the relevant multi-process and fault tests.
9. Never commit generated personal vault data, raw dogfood prompts, secrets, credentials, private paths, or unreviewed diagnostics.
10. Use an imperative conventional subject naming the result, for example `feat: serialize local update activation` or `test: prove restore rollback phases`.
11. In the commit body or evidence log, record the AC IDs advanced and exact verification commands.
12. Do not mark a milestone complete in the same commit that introduces unverified behavior. Verify first, then update its evidence/checklist in a small documentation checkpoint.
13. Do not rewrite or discard unrelated dirty work. If it overlaps the milestone, stop and reconcile ownership explicitly.
14. The final M8 candidate must be a clean commit with locked dependency resolution and reproducible artifacts.

## Evidence update rules

An acceptance checkbox may be checked only when its exact threshold and scope have current proof. Add one row per criterion or tightly coupled criterion group to the evidence ledger below.

Required evidence fields:

- AC or FIA ID.
- UTC date.
- Exact commit hash and release-binary hash where applicable.
- Exact command or reproducible manual drill.
- Result with denominator/threshold, not merely “passed.”
- Retained artifact or test name.
- Host/OS details for performance, package, release, and dogfood evidence.
- Reviewer/agent note explaining why the evidence proves the criterion.

Invalid evidence examples:

- “Code looks correct.”
- A test exists but was not run at the current commit.
- A unit test offered as proof of a required release-binary, host, process, fault, clean-machine, or dogfood scenario.
- A percentage without its numerator, denominator, fixture revision, and collision count.
- Performance numbers after matching/index code changed.
- A dogfood duration inferred from timestamps without real local-use observations.
- A clean-tree claim made before documentation/evidence changes are committed.

When implementation changes invalidate evidence, uncheck the affected criterion and mark the old row superseded. Matching/index changes invalidate functional, restore-behavior, and benchmark evidence. Policy/schema changes invalidate policy, learning, restore, and export evidence. Adapter changes invalidate FIA-5. Persistence changes invalidate concurrency and restore evidence. Metrics changes reset the dogfood interval unless shown to be presentation-only.

### Evidence ledger

| AC/FIA | Date (UTC) | Commit / binary | Command or drill | Result and threshold | Retained evidence | Status |
| --- | --- | --- | --- | --- | --- | --- |
| M1 supporting baseline | 2026-07-10 | `a584b1c` | Historical fixture/eval checkpoint | Source/probe fixture support and negative/generalization cases implemented; rerun required at current HEAD | Commit diff and eval fixtures | Superseded by later engine changes until rerun |
| M2–M5 historical targeted suite | 2026-07-10 | `816689d` | Historical full test/Clippy run reported in the execution conversation | 82 tests passed and Clippy was clean at that checkpoint; does not prove later commits | Conversation record and commit | Historical only |
| M2/M6/M7 implementation candidate | 2026-07-10 | `2a908b8` | Repository inspection | Hardening code and focused tests exist; no current full-run output recorded here | Commit diff and test names | Implementation evidence only |
| M1 and AC-FUN-001–015 | 2026-07-10 | `d93ea7ada09043a1422478b60d5f3223037ff8ad`; `brainmap` SHA `cb0f6ed0…8df75d` | `scripts/release-qualification.sh`; release-binary `eval` against `fixtures/decision-bench` | 238/238 cases: exact 6/6, paraphrase 10/10, negative specificity 207/207; zero false proceed/ask/block and zero outcome/choice/rule/metadata mismatch; ambiguity detected | `evidence/m001/d93ea7a/eval.json`; candidate README | Current targeted proof; M8 integration still required |
| M2 interface/schema v4 | 2026-07-10 | `d93ea7ada09043a1422478b60d5f3223037ff8ad` | Full locked all-target/all-feature suite and Clippy; focused `decision_engine`, `index`, `mcp`, and `harness` tests | 152 full-suite tests passed; schema v4/query-plan/capacity/determinism tests passed; Clippy passed with warnings denied | Named tests, `evidence/m001/d93ea7a/verification/03-cargo-test.log`, and `02-cargo-clippy.log` | Current targeted proof |
| AC-POL-001–007 | 2026-07-10 | `d93ea7ada09043a1422478b60d5f3223037ff8ad`; optimized drill SHA `d22e00e5…96cb2` | Structured-policy before/active/prose/retired, malformed-policy, and wikilink drills; qualification source/export/restore drill | Active policy changes the result, retired policy does not apply, invalid control fails closed, invalid non-control is excluded, prose is non-executable, wikilink survives, and causal metadata survives restore | `evidence/m001/d93ea7a/preflight/m4/`; source/restored policy gate JSON | Current targeted proof; preflight hash is not final reproducibility proof |
| AC-LRN-001–010 | 2026-07-10 | `d93ea7ada09043a1422478b60d5f3223037ff8ad`; optimized drill SHA `d22e00e5…96cb2` | Interactive and answer-file onboarding; dry-run/approval; ledger/feedback/correction/idempotency/secret drills; qualification export/restore | Three-question interactive flow passed; dry-run tree unchanged; ambiguous text pending; correction changed scoped next result; second apply was zero; secrets rejected; restored behavior equivalent | `evidence/m001/d93ea7a/preflight/m5/`; source/restored learned/corrected gates | Current targeted proof; preflight hash is not final reproducibility proof |
| AC-INT-001–009 | 2026-07-10 | `d93ea7ada09043a1422478b60d5f3223037ff8ad`; optimized drill SHA `d22e00e5…96cb2` | Optimized stdio/installer/doctor/hook preflight plus 7 harness, 7 MCP, 9 installer tests and Codex smokes | Structured stdio and invalid input passed; allowlisted MCP/approval tests passed; dry-run/backup/idempotency/unmanaged refusal passed; doctor healthy; enforcement labels and hook behavior accurate | `evidence/m001/d93ea7a/preflight/m6/`; `verification/03-cargo-test.log` | Current targeted proof; live Codex FIA-5 remains open |
| AC-DUR-001–010 | 2026-07-10 | `d93ea7ada09043a1422478b60d5f3223037ff8ad`; `brainmap` SHA `cb0f6ed0…8df75d` | Full concurrency/export tests plus qualification export/restore and eight injected restore failures | 16-process/serialized-update suites passed; checksum and behavioral equivalence passed; seven pre-activation faults retained the old complete vault and the post-activation fault retained the new complete vault | All `restore-fault-*.json`, `source-*.json`, and `restored-*.json` under `evidence/m001/d93ea7a/` | Current targeted proof |
| AC-SEC-001–008 | 2026-07-10 | `d93ea7ada09043a1422478b60d5f3223037ff8ad` | `cargo audit`; `cargo deny check`; patched-tree check; SBOM generation; full web/learning/export suites | No vulnerabilities; deny passed; `crossbeam-epoch` 0.9.20; tracked SBOM byte-identical; loopback, bounds/timeouts, secret exclusion, and import/archive validation passed | `brainmap.json`; `verification/05-cargo-audit.log`, `06-cargo-deny.log`, `07-crossbeam-tree.log`, `03-cargo-test.log` | Current targeted proof |
| AC-PERF-001–006 | 2026-07-10 | `d93ea7ada09043a1422478b60d5f3223037ff8ad`; `brainmap` SHA `cb0f6ed0…8df75d`; Linux 6.8.0-134 x86_64 | Locked optimized 1k/5k release-binary benchmarks, 10 warm-ups + 200 timed calls each | 1k: rebuild 133 ms, p95 2.672 ms (<10); 5k: rebuild 503 ms (<1 s), p95 10.810 ms (<25); prohibited hot-path operations false; candidate/posting bounds recorded | `bench-1000.json`, `bench-5000.json`, `qualification-manifest.json` | Current targeted proof on reference host |
| AC-REL-001–008 | 2026-07-10 | `d93ea7ada09043a1422478b60d5f3223037ff8ad`; both binary hashes in manifest | Format, all-feature Clippy/tests, locked optimized builds, audit/deny/SBOM, Cargo/npm packages, qualification, shell/workflow lint | 20/20 captured gates passed; 152 tests; Cargo verification build and four-file npm dry-run passed; CI definitions cover Linux/macOS/Windows and pass `actionlint` | `evidence/m001/d93ea7a/verification/verification-manifest.json`, complete logs, and top-level qualification manifest | Current targeted proof; no remote CI run ID claimed |
| FIA-1–8 and AC-REL-009–012 | — | Final post-dogfood candidate not yet selected | Clean-machine integrated drills, real Codex host FIA-5, 7–14 day shadow run, final release gate | Not run; synthetic qualification cannot substitute | Future FIA transcripts, dogfood aggregate report, final manifest | Pending M8 |

## Final completion rule

M001 is complete only when all eight milestone completion boxes are checked, every acceptance criterion has current evidence, FIA-1 through FIA-8 pass against optimized locked binaries on a clean local machine, the valid 1–2 week shadow dogfood interval is complete, no required work is deferred, product claims remain single-user and completely local, and the final worktree is clean.

Passing the existing test suite alone is not completion.
