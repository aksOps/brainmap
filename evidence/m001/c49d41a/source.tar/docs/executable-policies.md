# Executable Policies

Brainmap keeps Markdown canonical, but it does not execute arbitrary prose. A policy becomes executable only when its Markdown contains a validated deterministic rule marker.

## Contract

An executable policy is a normal Brainmap note with:

- a unique `id`;
- a supported executable `type`: `decision-policy`, `hard-constraint`, `approval-rule`, `meta-rule`, `decision-example`, or `corrected-decision`;
- a supported `status`: active `seed`, `tested`, or `reliable`, or inactive `retired`, `stale`, or `contradicted`;
- a `confidence`, `risk_tier`, and `sensitivity`;
- one `brainmap-decision-rule:v1` marker.

Example:

```markdown
---
id: package-manager-policy
type: decision-policy
status: reliable
confidence: high
risk_tier: reversible-auto
sensitivity: personal
---
# Package Manager Policy

## Deterministic Rule

<!-- brainmap-decision-rule:v1 {"situation":"Choose package manager for a JavaScript project","decision_type":"tooling","scope":"global","options":["npm","pnpm"],"chosen":"pnpm","rejected":["npm"]} -->
```

The marker fields are:

- `situation`: required non-empty decision situation;
- `decision_type`: optional lowercase ASCII decision category using letters, digits, `-`, or `_`;
- `scope`: optional `global`, `project:<id>`, or `repository:<id>`;
- `options`: the known options for the rule;
- `chosen`: required choice, and a member of `options` when options are supplied;
- `rejected`: choices explicitly rejected by the rule.

Unknown fields, malformed JSON, invalid scope/type values, an empty situation or choice, and a choice rejected by the same rule are invalid.

## Status

Rules with `retired`, `stale`, or `contradicted` status are compiled for inspection but never applied. Active status changes take effect after `brainmap index rebuild`.

## Failure behavior

Malformed executable control policies fail index rebuild closed and report the note path. Malformed non-control learned examples are excluded with a warning so one bad example cannot disable safety controls.

Free prose, headings, evidence, and wikilinks remain human context. Editing prose does not silently change gate behavior.
