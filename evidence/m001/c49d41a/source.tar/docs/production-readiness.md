# Production Readiness

Target: single-user local Brainmap on the qualified Linux x86_64 release host, with embedded SQLite and a bundled local model.

Supported release shape:

- Local-only runtime; no network service required.
- Cargo registry source install downloads the model at build time and embeds it into the binary.
- Linux x86_64 npm binary package from `v*.*.*` Git tags.
- Linux x86_64 GitHub release tarball plus `SHA256SUMS`.
- Other Linux distributions may build from source, but this milestone does not claim distro-specific qualification beyond the recorded Linux x86_64 reference host.
- Markdown is canonical. SQLite, embeddings, snapshots, and exports are rebuildable.

## Install

```bash
npm install -g @aksops/brainmap
cargo install brainmap-cli
brainmap init --dry-run
brainmap init-vault --vault ~/BrainMap --yes
brainmap index rebuild --vault ~/BrainMap
brainmap models materialize --vault ~/BrainMap
brainmap models verify --vault ~/BrainMap
brainmap embed rebuild --vault ~/BrainMap
```

Source install:

```bash
cargo install --path crates/brainmap-cli
brainmap init --dry-run
brainmap init-vault --vault ~/BrainMap --yes
brainmap index rebuild --vault ~/BrainMap
brainmap models materialize --vault ~/BrainMap
brainmap models verify --vault ~/BrainMap
brainmap embed rebuild --vault ~/BrainMap
```

Versioned release:

```bash
git tag -a v0.1.0 -m "v0.1.0"
git push origin v0.1.0
sha256sum -c SHA256SUMS
```

The release workflow publishes `brainmap-vX.Y.Z-linux-x86_64.tar.gz`, `brainmap-vX.Y.Z-linux-x86_64-qualification.tar.gz`, and a standalone CycloneDX SBOM. `SHA256SUMS` covers all three flat release assets. Cargo crates publish when `CARGO_REGISTRY_TOKEN` is configured, and `@aksops/brainmap` publishes when `NPM_TOKEN` is configured. The same SBOM is retained inside the binary release tarball as `brainmap.cdx.json`.

Cargo registry shape:

- `brainmap-cli` publishes without model bytes in the crate package.
- `build.rs` downloads and checksum-verifies `minishlab/potion-base-8M`, then embeds the generated pack.
- `cargo install brainmap-cli` needs network and `curl` at build/install time. No runtime model download is introduced.

## Autonomous Checks

CI runs on Linux, macOS, and Windows:

```bash
cargo fmt --check
cargo clippy --all-targets --all-features -- -D warnings
cargo test
```

Linux security/SBOM and tagged-release gates:

```bash
cargo audit
cargo deny check
scripts/test-vendored-i18n.sh
cargo audit --file vendor/i18n-embed-fl/Cargo.lock
scripts/generate-sbom.sh
scripts/verify-release-reproducibility.sh
```

The SBOM generator removes machine-local paths and nondeterministic metadata.
CI regenerates it and requires a byte-identical tracked artifact. The vendored
macro has a content-derived component reference, SHA-256 over its sorted Git
index source manifest, relative vendor path, and the upstream fix commit as
provenance. Unexpected non-ignored files under the vendor directory fail SBOM
generation instead of silently changing its identity.

The release reproducibility check snapshots the candidate into two isolated
source roots, performs two locked optimized builds with compiler wrappers
disabled, and byte-compares both isolated outputs. Only after both binaries
match does it atomically install the verified outputs into the root
`target/release` directory that qualification, npm preparation, and release
packaging consume. `age` 0.11.x requires `i18n-embed-fl` 0.9.x, whose published
procedural macro emits named arguments in randomized `HashMap` order. Brainmap
vendors the exact MIT-licensed 0.9.4 source with the argument-ordering patch
from upstream commit `f02d3ca8acb0c197290f13934aa9541f1e12b097`: collect into a
vector, reject duplicate keys, and sort keys before code generation. Two
focused parser tests cover ordering and duplicate rejection.

The vendored 0.9.4 crate is intentionally outside workspace lint ownership so
the reproducibility fix does not absorb unrelated upstream Clippy debt. Its
committed lockfile is part of the SBOM source-tree identity and has a dedicated
`cargo audit --file` gate. CI runs the focused tests with `--locked` through
`scripts/test-vendored-i18n.sh`; the helper keeps build output outside the
vendor source tree and verifies the lock remains unchanged. Workspace Clippy
and tests continue to compile and exercise the patched dependency in Brainmap.

The workspace patch applies to repository-built GitHub and npm binaries. Cargo
does not publish root workspace patches with `brainmap-cli`, so
`cargo install brainmap-cli` remains functionally equivalent but is not
claimed byte-identical until `age` accepts `i18n-embed-fl` 0.10.x.

`cargo test` includes a CLI production smoke covering vault init, index verify, hot-path gate/context, model materialization, local embeddings, vector/hybrid search, export/import/restore, tamper rejection, snapshots, and eval.

## Scale Envelope

Primary supported target:

- 1k-5k curated Markdown files.
- One embedded SQLite index.
- One `minishlab/potion-base-8M` 256-dimensional `f32` embedding per note.
- Current vector search is SQLite read plus in-process cosine scan.

Stretch target:

- 10k-25k files only after benchmark proof on the release target.

Not a target:

- 100k+ files.
- Millions of chunks.
- General document archive or RAG behavior.

Run scale checks on the Linux release binary:

```bash
brainmap bench --vault /tmp/brainmap-scale-1000 --scale 1000
brainmap bench --vault /tmp/brainmap-scale-5000 --scale 5000 --embeddings
```

`--scale` writes deterministic benchmark notes under `90-calibration/scale-bench` and replaces only that directory. `--embeddings` includes model materialization, embedding rebuild, and vector search timing.

The current optimized decision-gate baseline is recorded in [performance-baseline.md](performance-baseline.md):

| Files | Index rebuild | Gate p50 | Gate p95 | Gate budget |
| --- | ---: | ---: | ---: | ---: |
| 1k executable rules | 133 ms | 2.548 ms | 2.672 ms | < 10 ms p95 |
| 5k executable rules | 503 ms | 9.831 ms | 10.810 ms | < 25 ms p95 |

Treat these as a sanity baseline, not a hardware guarantee.

## Backup Drill

```bash
brainmap export --mode portable --vault ~/BrainMap --out ./brainmap.brainmap.tar.zst
brainmap verify-export ./brainmap.brainmap.tar.zst
brainmap restore --file ./brainmap.brainmap.tar.zst --to ./BrainMap-restored
brainmap snapshot create --vault ~/BrainMap
brainmap snapshot list --vault ~/BrainMap
```

Portable/full backup refuses secret-classified or secret-like files. Share-safe export omits them. Archive verification repeats schema, checksum, portability, traversal, collision, and secret validation before restore writes staging data.

## Codex adapter

```bash
brainmap install harness --target codex --project . --vault ~/BrainMap --dry-run
brainmap install harness --target codex --project . --vault ~/BrainMap
brainmap integration doctor --target codex --project . --vault ~/BrainMap
```

The installer preserves user content, backs up changed files, is idempotent, and refuses unmanaged owned files or an unmanaged Brainmap MCP table. Codex pre-tool hooks are `enforced` only for observable safety/approval boundaries. MCP is `best-effort`; skill and project instructions are `instruction-only`. Personal decisions must use the structured MCP gate. Learning defaults to a stable project-local scope.

## Shadow-mode dogfood

Keep the default shadow configuration during the real-use qualification period. Hosts should pass structured decisions through the gate, then link the actual action to the returned decision ID:

```bash
brainmap gate --json --vault ~/BrainMap \
  --situation "Choose formatter for this repository" \
  --options "biome|prettier" --risk low --reversible true \
  --decision-type tooling --scope project:example
brainmap record-decision --vault ~/BrainMap \
  --decision-id dec_... --chosen biome --was-asked false
brainmap learn-feedback --vault ~/BrainMap \
  --decision-id dec_... --chosen prettier --rejected biome
brainmap autopilot status --vault ~/BrainMap
```

When feedback confirms an incident, add one of `--incident false-proceed`, `--incident cross-domain-application`, `--incident privacy-violation`, or `--incident hard-rule-violation`. `autopilot status` reports aggregate exact/fuzzy match rates, agreement, correction, false-ask, automatic candidate-collision rates, separately labeled confirmed-collision/cross-domain rates, mean match margin, p50/p95 latency, observation duration, false proceeds, and privacy/hard-rule violations. The aggregate contains no raw prompts. Do not promote based only on synthetic tests: M001 requires 1-2 weeks of local use with zero safety false-proceeds and no confirmed cross-domain learned-rule application.

Use encrypted export when backups leave the machine:

```bash
brainmap export --mode portable --encrypt --recipient age1... --vault ~/BrainMap --out ./brainmap.brainmap.tar.zst.age
brainmap verify-export ./brainmap.brainmap.tar.zst.age --identity ./identity.txt
```

## Known Ceilings

- Vector search scans SQLite-stored vectors in-process. Good for the 1k-5k personal decision scale; add sqlite-vec/ANN only after measured latency.
- MCP server is the narrow stdio tool surface Brainmap needs, not a broad general-purpose server.
- Canonical data is Markdown; SQLite and embeddings are rebuildable.
- Web serving is loopback-only. Remote access is not supported.
- Host adapter artifacts are labeled `enforced`, `best-effort`, or `instruction-only`; only pre-tool hooks and the generic stdio harness can enforce a pre-action result.
- Shadow-mode promotion remains evidence-gated. A 1-2 week real-use dogfood period is required before claiming the full M001 release goal complete.
