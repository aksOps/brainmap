# Decision Gate Performance Baseline

Recorded 2026-07-10 for Brainmap 0.1.0. These measurements are release sanity baselines for the supported local 1k-5k-note envelope, not guarantees for every machine.

## Reference host

- Linux 6.8.0-134-generic, x86_64.
- AMD EPYC 9354P; the container exposed 6 logical CPUs.
- Rust 1.95.0.
- `scripts/verify-release-reproducibility.sh` built the repository GitHub/npm
  release binaries byte-identically in two isolated source roots and installed
  the verified outputs into `target/release`.
- Embedded SQLite and no embeddings, model loading, network, LLM, or AgentMemory on the gate hot path.

## Results

Each gate result uses 10 warm-up calls followed by 200 timed dry-run calls. The benchmark reports sub-millisecond samples rather than rounding them to integer milliseconds.

| Notes | Index rebuild | Gate p50 | Gate p95 | Gate max | Required budget |
| ---: | ---: | ---: | ---: | ---: | ---: |
| 1,000 executable rules | 133 ms | 2.548 ms | 2.672 ms | 3.432 ms | p95 < 10 ms |
| 5,000 executable rules | 503 ms | 9.831 ms | 10.810 ms | 13.323 ms | p95 < 25 ms; rebuild < 1 s |

Candidate retrieval is explicitly bounded to 5,000 executable rules, 5,000 posting rows per term, 32 request options, and 16 normalized query terms (at most 80,000 indexed posting visits). Indexed term postings compute symmetric Jaccard and anchor compatibility for each actual rule; SQL window ranking retains one best real rule per normalized choice, then returns at most one candidate for each of the 32 current choices plus the 8 highest-scoring relevant unavailable choices. At most 33 exact candidates or 40 fuzzy candidates reach Rust validation and final conflict resolution. This prevents duplicate-rule crowding and synthetic relevance assembled from unrelated rules. Actual-rule relevance ranks before scope, decision type, option compatibility, and classification priority.

## Matcher thresholds

- Minimum fuzzy score: `0.75` symmetric token Jaccard after synonym normalization.
- Ambiguity margin: less than `0.10` between otherwise equivalent conflicting choices.
- Operation and domain anchors must not conflict when both situations expose a recognized anchor.
- Confidence uses match kind, score, candidate margin, evidence count, exact-scope compatibility, declared rule confidence, and correction classification.

The 2026-07-10 deterministic suite contains 238 cases. At these thresholds it recorded 6/6 exact applications, 10/10 supported paraphrases, 207/207 negative-specificity results, zero false proceeds, and zero outcome, choice, rule, or metadata mismatches. The scale figures above use 1,000 and 5,000 actual executable rules. Both runs returned the expected explicit ambiguous collision and exercised a high-confidence unavailable-choice fallback after 129 current-choice distractors. This is the retained recall/collision trade-off baseline; changes to anchors, thresholds, or retrieval require a new eval result and executable-rule scale run.

Raw qualification output, commit and binary hashes, host/toolchain details, and
recovery evidence are retained under
[`evidence/m001/d93ea7a`](../evidence/m001/d93ea7a/README.md).

## Reproduce

```bash
rtk scripts/verify-release-reproducibility.sh
rtk target/release/brainmap bench --vault /tmp/brainmap-scale-1000 --scale 1000
rtk target/release/brainmap bench --vault /tmp/brainmap-scale-5000 --scale 5000
```

Run on an otherwise quiet local host and retain the JSON output when comparing a future release. A regression beyond the milestone budgets blocks release until explained or fixed.
