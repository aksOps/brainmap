# Local Onboarding

Interactive onboarding asks three predefined local-development calibration questions, maps recognized answers into executable project-scoped rules, and activates them only after a preview and confirmation:

```bash
brainmap onboard --vault ~/BrainMap
```

The predefined questions cover existing formatter configuration, existing test-command configuration, and dependency changes without a prior preference. Answer with the displayed number or exact choice. An unfamiliar free-text answer remains pending clarification instead of becoming executable. After the three required questions, additional custom decisions are optional. Every implicit scope is a stable project-local scope derived from the current directory; global learning is never implicit.

For repeatable setup, use a versioned answer file. Preview it first, then activate it explicitly:

```bash
brainmap onboard --answers ./brainmap-onboarding.json --vault ~/BrainMap --dry-run
brainmap onboard --answers ./brainmap-onboarding.json --vault ~/BrainMap --yes
```

```json
{
  "schemaVersion": "brainmap-onboarding-v1",
  "decisions": [
    {
      "situation": "Choose package manager for a JavaScript project",
      "decisionType": "tooling",
      "scope": "project:example",
      "options": ["npm", "pnpm"],
      "chosen": "pnpm",
      "rejected": ["npm"],
      "rationale": "Use one fast deterministic package manager"
    }
  ]
}
```

A concrete `chosen` value must be present in `options`. Before confirmation, Brainmap prints the exact JSON update packet—including its ID, target path, structured rule, options, rejected values, scope, and rationale-derived evidence—that the same process will write and activate. The resulting rule is scoped, written as reviewed Markdown through that update packet, and compiled into SQLite.

An answer that is not concrete enough to choose an option can use `freeText` instead of `chosen`. Brainmap records it in `90-calibration/pending-onboarding.jsonl` with status `pending-clarification`; it does not become executable behavior. Secret-like content is rejected before either path persists it.
