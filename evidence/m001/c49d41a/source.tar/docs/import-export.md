# Import Export

Portable exports are `.brainmap.tar.zst` archives with `manifest.json`, checksums, Markdown vault files, config, ledgers, and pending packets.

Encrypted exports use age-compatible recipient encryption:

```bash
brainmap export --mode portable --encrypt --recipient age1... --vault ./tmp/BrainMap --out ./tmp/brainmap.brainmap.tar.zst.age
brainmap verify-export ./tmp/brainmap.brainmap.tar.zst.age --identity ./identity.txt
brainmap restore --file ./tmp/brainmap.brainmap.tar.zst.age --identity ./identity.txt --to ./tmp/Restored
```

Excluded by default:

- SQLite index
- model cache
- locks
- large backups
- secrets

Portable and full export fail if a source file, binary byte stream, archive identifier/path, or manifest metadata is secret-classified or contains secret-like material. Share-safe export omits such files. Verification applies the same checks to hand-crafted archives before restore writes staging data.

Restore validates format and decision-schema versions, manifest/checksums, portable paths, collisions, and secret classification; writes a staging vault; rebuilds and integrity-checks schema v4; checks wikilinks; runs a gate smoke test; and only then swaps the target. A canonical-path-derived process lock lives beside the vault rather than inside the swappable directory, so index, update, snapshot, export, and restore operations remain mutually exclusive across replacement. Existing symlink aliases resolve to the same lock and restore the real target while preserving the alias. A pre-existing target is retained as a backup.
