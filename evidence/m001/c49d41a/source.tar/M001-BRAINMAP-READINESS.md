# M001: Trusted Local Decision Engine

Status: Active
Owner: Unassigned  
Target: Single-user, completely local Brainmap for individual developers  
Completion class: Functional contract + host integration + operational proof

## Goal Prompt

> Make Brainmap a functionally trustworthy local decision engine for an individual developer. A developer must be able to initialize Brainmap, express and correct concrete preferences, have those preferences reliably affect future decisions across reasonable paraphrases without leaking into unrelated decisions, use the engine through a supported local agent integration, and recover all behavior after backup and restore. Preserve the deterministic, local-only gate and complete every acceptance criterion in this document before declaring the goal achieved.

## Project Description

Brainmap already has a working local vault, rebuildable SQLite index, deterministic decision gate, update packets, learned decisions, correction precedence, local search, embeddings outside the hot path, integrations, and verified backup and restore. This milestone turns that functional MVP into a dependable personal decision engine. It focuses on the quality of decisions and the completeness of the learning loop, then hardens local concurrency, recovery, security, and release proof.

## Why This Milestone

At the milestone start, the core mechanism was real: a learned decision changed a later gate result, corrections superseded older decisions, and learned behavior survived export and restore. The baseline token-overlap matcher still missed reasonable paraphrases and applied preferences to unrelated decisions; unlearned low-risk choices could depend on option order; confidence was not match-derived; policy Markdown was not causally executed; onboarding did not consume answers; and host hooks did not complete the learning loop. M001 exists to close and prove those baseline gaps; current implementation and qualification status are recorded in `M001-EXECUTION-ROADMAP.md`.

## User-Visible Outcome

When this milestone is complete, an individual developer can:

1. Install and initialize Brainmap locally without any runtime network or model download.
2. Complete an interactive or file-driven onboarding flow and review the policies it will activate.
3. Teach Brainmap a scoped decision such as a project-specific formatter or a global approval rule.
4. Ask the same decision using ordinary paraphrases and receive the same applicable choice.
5. Ask a nearby but unrelated question without the earlier preference leaking into it.
6. Correct a decision and see the correction take precedence on the next gate call after approval.
7. Edit a structured Markdown policy, rebuild the index, and observe the corresponding gate behavior change.
8. Use Brainmap through generic stdio and at least one supported coding-agent adapter.
9. See which exact policy or learned rule caused a result, its scope, match kind, match score, and calibrated confidence.
10. Run multiple local agent processes without corrupting ledgers, packets, snapshots, or the index.
11. Export, verify, restore, and recover the same policies and learned decisions.
12. Keep all gate execution deterministic, bounded, and local.

## Completion Class

This is not complete with unit tests alone. Completion requires:

- Contract proof at the decision-engine interface.
- Integration proof through real CLI and host-adapter flows.
- Operational proof for concurrency, restore failure, release binaries, and the documented 1k-5k-note envelope.
- A shadow-mode dogfood period demonstrating acceptable agreement and correction behavior on real local decisions.

## Final Integrated Acceptance

The following scenarios must pass against an optimized release binary on a clean local machine:

### FIA-1: First-run onboarding

1. Initialize a new vault.
2. Run onboarding and answer at least three calibration questions.
3. Preview the generated policies.
4. Approve them.
5. Confirm the index rebuilds automatically.
6. Run example gate requests and observe behavior derived from those answers.

### FIA-2: Learned decision generalization

1. Teach a project-scoped formatter decision.
2. Confirm the exact situation selects the learned option.
3. Confirm at least five curated paraphrases select the same option.
4. Confirm formatter decisions in another ecosystem do not inherit the rule.
5. Confirm database, logging, and package-manager decisions in the same project do not inherit the rule.

### FIA-3: Correction loop

1. Run a non-dry gate decision and record its decision ID.
2. Submit a structured correction.
3. Preview and approve the update packet.
4. Confirm the corrected choice wins on the next applicable request.
5. Confirm the correction does not outrank a more relevant rule in another scope or decision type.

### FIA-4: Executable Markdown policy

1. Add a valid structured policy note.
2. Rebuild the index.
3. Confirm the policy changes a matching gate result.
4. Retire the policy and rebuild.
5. Confirm it no longer applies.
6. Confirm reported applied policies contain only rules that causally affected the outcome.

### FIA-5: Host integration

1. Install a supported host adapter using dry-run first.
2. Run the integration doctor and receive a healthy result.
3. Make a structured decision through the host.
4. Confirm the host follows `outcome` and `selectedOption`.
5. Record the action and submit a correction through the supported learning interface.
6. Approve the update and confirm the next host decision changes.

### FIA-6: Concurrent local operation

1. Run at least 16 concurrent gate and recording processes.
2. Apply concurrent capture and feedback traffic.
3. Confirm every JSONL line is valid and complete.
4. Confirm every ID is unique.
5. Confirm no update packet or canonical Markdown note is lost or truncated.

### FIA-7: Backup and recovery

1. Export a populated vault.
2. Verify checksums.
3. Restore into a new target.
4. Confirm learned, corrected, and policy-driven decisions are identical.
5. Inject a failure during restore and confirm either the old complete vault or the new complete vault remains active, never a partial replacement.

### FIA-8: Release gate

1. Run formatting, Clippy, all tests, audit, deny, SBOM generation, and locked release builds.
2. Run package smoke tests.
3. Run the 1k and 5k scale checks.
4. Confirm the gate remains within the performance budget.
5. Confirm the worktree is clean after verification.

## Architectural Decisions

### Decision 1: One deep decision-engine module

Expose one small `evaluate(request) -> result` interface. Hide safety precedence, policy evaluation, rule matching, conflicts, confidence, and SQLite access behind it. CLI, MCP, stdio, and host integrations must all cross this same seam.

Rationale: one behavioral interface provides leverage for callers and locality for correctness fixes and testing.

Alternatives considered:

- Continue adding branches to the current gate implementation: rejected because matching, storage, and presentation concerns would remain coupled.
- Let every host interpret policies independently: rejected because behavior would diverge across integrations.

### Decision 2: Structured Markdown is the executable source

Markdown remains canonical. Only validated structured rule fields or deterministic rule markers become executable. Free prose remains human context and does not silently alter gate behavior.

Rationale: deterministic compilation makes behavior reviewable, testable, and rebuildable while preserving wikilinks and local ownership.

Alternatives considered:

- Execute arbitrary prose heuristically: rejected because results would be difficult to explain or reproduce.
- Make SQLite canonical: rejected because it violates the local Markdown ownership model.

### Decision 3: Deterministic scoped matching in the gate

The hot path uses bounded deterministic lexical and structural matching. It must consider decision type, project/global scope, operation/domain anchors, current options, relevance margin, rule status, and evidence. No LLM, AgentMemory, embedding generation, external provider, or runtime model load is permitted in the gate.

Rationale: the gate must remain fast, offline, explainable, and repeatable.

Alternatives considered:

- Generate embeddings during gate evaluation: rejected by the hot-path contract.
- Use simple one-sided token overlap: rejected because it caused both misses and cross-domain collisions.

### Decision 4: Learned decisions default to the narrowest safe scope

Learning from a project decision defaults to project or repository scope. Global promotion is explicit and reviewable.

Rationale: an individual developer may prefer different tools in different repositories; narrow defaults prevent accidental preference leakage.

Alternatives considered:

- Make all learning global: rejected because a single example would overgeneralize.
- Require scope on every command: rejected as unnecessarily burdensome when the current project can provide a safe default.

### Decision 5: Explicit activation of learning

Capture and feedback create draft update packets. A preview and explicit approval are required before new behavior becomes active.

Rationale: local autonomy should not silently turn ambiguous observations into durable policy.

Alternatives considered:

- Automatically apply every correction: rejected because parsing or scope could be wrong.
- Store feedback only as prose: rejected because corrections must be able to affect future decisions.

### Decision 6: Relevance precedes policy priority

Correction and policy priority resolve conflicts only among sufficiently relevant, scope-compatible candidates. A weakly related corrected rule cannot outrank a strongly related normal rule solely because it has a higher classification priority.

Rationale: precedence must not amplify fuzzy-match errors.

### Decision 7: Local-only web behavior is enforced

The web UI binds to loopback by default and rejects non-loopback binding unless a separately reviewed remote-access mode is explicitly enabled.

Rationale: read-only endpoints still expose personal decisions and policy information.

## Error Handling Strategy

- Invalid or missing decision context returns `needs_more_context` with a focused request for missing fields.
- Safety invariant matches return `block` or `ask_user`; they never fall through to permissive defaults.
- Ambiguous rule matches return `ask_user` and identify the conflict without pretending to have high confidence.
- A learned choice absent from current options does not automatically produce an irrelevant question. Exact high-confidence matches may ask about changed options; weak matches are treated as no match.
- Invalid executable policy fields fail compilation with the note path and field name.
- Invalid control policies fail closed. Invalid non-control policies are excluded with an actionable compiler warning.
- Learning text that cannot be parsed unambiguously remains pending and shows the user what is missing.
- Secret-like content is rejected or redacted before ledger, packet, policy, export, or diagnostic persistence.
- Lock contention reports which operation owns the lock and supports bounded retry where safe.
- Stale locks are detected and recoverable without deleting active locks.
- Restore validates in staging and automatically rolls back a failed swap.
- Integration doctor errors distinguish missing executable, invalid host configuration, missing vault, unsupported enforcement, and unhealthy gate.
- Every CLI failure returns a nonzero exit code and a concise recovery instruction.

## Risks and Unknowns

- Deterministic lexical matching may require careful anchor extraction to achieve paraphrase recall without collision. Thresholds must be chosen from evaluation evidence, not intuition.
- Some coding hosts cannot expose all events required for automatic record and feedback flows. Enforcement and learning claims must remain host-specific and honest.
- Free-text onboarding cannot safely become executable without either a constrained local syntax or an agent-assisted slow path. It must remain pending when interpretation is uncertain.
- Cross-platform atomic replacement and locking differ between Unix and Windows and require target-specific tests.
- Transitive dependencies may constrain how quickly current audit warnings can be eliminated.

## Existing Codebase / Prior Art

- `gate` contains the current decision precedence, result format, safety checks, defaults, and learned-rule application.
- `index` builds the SQLite index, compiles deterministic decision markers, searches notes, and performs the current token-overlap match.
- `learning` manages onboarding questions, ledgers, feedback, update packets, application, autopilot, and gate modes.
- `markdown` parses frontmatter, wikilinks, and deterministic decision markers.
- `harness` implements generic stdio and host hook translation.
- `install` writes skills, instructions, and hook configurations with dry-run and backup behavior.
- `mcp` exposes the current allowlisted local tool surface.
- `export` and `snapshot` implement checksummed archive, restore, snapshot, and rollback flows.
- `util` implements identifiers, atomic writes, JSONL append, archive path safety, and index locking.
- `eval` runs the current deterministic decision benchmark.
- The decision benchmark fixtures provide the existing safety, ambiguity, storage, learning, and configuration cases.

## Relevant Requirements

### R-FUN: Trustworthy decisions

Brainmap must apply learned and policy decisions to the intended situation and scope, generalize across supported paraphrases, and avoid unrelated applications.

### R-EXP: Explainability

Every nontrivial result must identify the causal rule, scope, match kind, score, confidence, and restrictions.

### R-LRN: Complete learning loop

Onboarding, decision recording, feedback, preview, approval, compilation, and subsequent behavior change must work end to end.

### R-INT: Usable integrations

At least generic stdio and one coding-agent adapter must support the documented gate and learning contract.

### R-LOC: Local deterministic hot path

Gate evaluation must not call network, LLMs, AgentMemory, embedding generation, external embedding providers, or runtime model downloads.

### R-DUR: Durable canonical state

Concurrent use, interrupted writes, export, restore, and rebuild must preserve canonical Markdown and valid ledgers.

### R-SEC: Local security

Secret material must not be persisted, release dependencies must pass audit policy, and local UI data must not be exposed by default.

### R-PERF: Bounded performance

The gate must stay deterministic and bounded at the supported 1k-5k-note scale.

## Scope

### In Scope

- Decision-engine module and interface.
- Schema v4 for compiled policies and learned rules, superseding v3 with bounded choice-keyed postings.
- Scoped exact and deterministic fuzzy matching.
- Confidence and ambiguity derived from match evidence.
- Removal of arbitrary first-option personalization.
- Executable structured Markdown policies.
- Real onboarding and structured feedback preview.
- Richer decision ledger and update packets.
- Generic stdio, MCP, and at least one coding-agent adapter.
- Integration diagnostics.
- Concurrent-safe IDs, writes, ledgers, updates, index rebuild, and restore.
- Dependency audit remediation.
- Loopback enforcement for the web UI.
- Evaluation, property, integration, concurrency, fault, scale, and release tests.
- Shadow-mode dogfooding.

### Out of Scope

- Multi-user or shared server operation.
- Cloud synchronization or hosted Brainmap service.
- Runtime LLM inference inside the gate.
- Runtime embedding generation inside the gate.
- External embedding providers.
- General document archive, transcript archive, or RAG chatbot behavior.
- 100k+ note scale.
- Automatic activation of unreviewed learning.
- Remote web access unless separately designed and reviewed.

### Non-Goals

- Inferring every preference from arbitrary prose.
- Eliminating all questions; correct uncertainty is preferable to a wrong automatic decision.
- Making SQLite canonical.
- Supporting every coding-agent host in this milestone.
- Replacing existing checksum validation or wikilink behavior.

## Technical Constraints

- Markdown remains canonical; SQLite and embeddings are rebuildable indexes.
- Preserve all wikilinks.
- No secrets in persistent state.
- Every schema change requires tests.
- Every installer path retains dry-run and backup behavior.
- Every import/export path retains checksum validation.
- Every gate behavior change requires evaluation cases.
- The gate performs no network, LLM, AgentMemory, embedding generation, external embedding-provider call, runtime model download, or runtime model load.
- Default embeddings remain the embedded `minishlab/potion-base-8M` pack outside the hot path.
- Candidate retrieval and scoring must remain explicitly bounded.
- The supported primary scale remains 1k-5k curated Markdown notes.
- Linux-family systems remain the primary release target; CI continues to cover macOS and Windows behavior where supported.

## Integration Points

- CLI commands for gate, context, onboarding, learning, feedback, apply, index, doctor, export, restore, and evaluation.
- SQLite compiled index and manifest.
- Markdown policy and learned-decision notes.
- JSONL decision and capture ledgers.
- Update packet review and application.
- MCP allowlisted tools.
- Generic stdio harness.
- Codex, Claude Code, or OpenCode adapter selected as the first fully proven coding-host integration.
- Web UI status and read-only data endpoints.
- Cargo, npm, GitHub Actions, audit, deny, and SBOM release gates.

## Testing Requirements

### Interface tests

Test the decision engine through its public `evaluate` interface. Tests must assert observable outcomes, choices, causal rules, ambiguity, scope, and confidence metadata rather than internal helper behavior.

### Evaluation suites

Include exact, paraphrase, negative collision, cross-project, option mismatch, conflict, correction, ambiguity, privacy, high-risk, and configuration cases. Evaluation fixtures must allow learned source situations to differ from probe situations.

### Property tests

Verify:

- A selected option belongs to the request options or an explicitly declared policy default.
- High-risk irreversible actions never proceed.
- Secret-like material is never persisted.
- The same state and request produce the same substantive result.
- Narrower scopes do not leak into broader or different scopes.
- A weak fuzzy match cannot become high confidence.
- Candidate retrieval remains bounded.

### Integration tests

Exercise onboarding, learn, apply, gate, record, correct, reapply, search, export, verify, restore, and post-restore gate behavior through the release binary.

### Adapter tests

Use golden host payloads and verify parsing, request construction, enforcement result, user-facing output, recording, and feedback behavior for every advertised adapter.

### Concurrency and fault tests

Use multiple processes, not only threads. Validate unique IDs, complete JSONL records, serialized packet application, index locking, stale-lock recovery, and restore rollback at injected failure points.

### Performance tests

Benchmark the optimized binary at 1k and 5k notes. Record p50 and p95 gate latency and verify candidate bounds.

### Release tests

Run formatting, Clippy with warnings denied, all targets, audit, deny, SBOM generation, locked package and release builds, npm package tests, and archive checksum verification.

## Execution Roadmap

### Slice 1: Evaluation baseline

Outcome: every observed matcher failure is reproducible in the automated evaluation suite.

Work:

- Extend evaluation fixtures to separate learned-source situations from probe situations.
- Add paraphrase, collision, cross-project, option, and precedence cases.
- Record the current baseline without weakening expected results.

Exit criteria: AC-FUN-001 through AC-FUN-004 have automated failing tests that become the contract for later slices.

### Slice 2: Decision-engine interface and schema v4

Outcome: all callers use one decision interface and the compiled index stores scope, decision type, options, evidence, and match metadata.

Work:

- Introduce decision request/result and rule-resolution types.
- Add the deep decision-engine module.
- Add schema v4 and rebuild behavior. Schema v4 supersedes the original v3 layout with bounded choice-keyed postings.
- Preserve CLI JSON compatibility where possible; version intentional changes.

Exit criteria: the index rebuilds deterministically, schema tests pass, and CLI/MCP/harness evaluation crosses the new interface.

### Slice 3: Scoped matcher and confidence

Outcome: exact and supported paraphrased decisions match narrowly without cross-domain leakage.

Work:

- Implement scope and decision-type filters.
- Add bidirectional lexical scoring and operation/domain anchors.
- Add option compatibility, best-candidate margin, and ambiguity handling.
- Make relevance precede classification priority.
- Derive confidence from evidence.
- Remove automatic first-option personalization.

Exit criteria: all functional matching criteria pass, including zero false matches in the negative suite.

### Slice 4: Executable policy compiler

Outcome: validated structured Markdown policies causally affect gate results and are reported accurately.

Work:

- Define and document the policy rule contract.
- Compile active policies and learned decisions into one representation.
- Keep safety invariants as named highest-precedence rules.
- Report applied versus merely considered policies.
- Add conflict and invalid-policy behavior.

Exit criteria: AC-POL-001 through AC-POL-007 pass.

### Slice 5: Onboarding and learning workflow

Outcome: a developer can answer questions, preview policies, approve them, correct decisions, and observe changed future behavior.

Work:

- Add interactive and answer-file onboarding.
- Map predefined answers to structured policies.
- Keep ambiguous free text pending.
- Enrich decision ledger records.
- Add structured feedback and preview.
- Consolidate pending, preview, apply, reject, and conflict commands.

Exit criteria: AC-LRN-001 through AC-LRN-010 pass through the release binary.

### Slice 6: Host adapters and diagnostics

Outcome: generic stdio and one coding-agent host complete the gate, record, correction, and activation loop.

Work:

- Define the harness-adapter seam.
- Extend MCP with narrow learning tools.
- Implement host-specific event translation and honest enforcement labels.
- Add integration doctor and golden-payload tests.
- Preserve installer dry-run, backup, idempotency, and unmanaged-file protection.

Exit criteria: AC-INT-001 through AC-INT-009 pass.

### Slice 7: Durability, security, and release proof

Outcome: Brainmap is safe under concurrent local agents, recoverable from interrupted restore, clean under release security gates, and proven at supported scale.

Work:

- Add unique IDs, unique temporary files, parent sync, and process locks.
- Stage and transactionally swap restores with rollback.
- Patch known dependency advisories.
- Enforce local-only web binding.
- Add concurrency, fault, scale, package, and release verification.
- Complete shadow-mode dogfooding.

Exit criteria: AC-DUR, AC-SEC, AC-PERF, and AC-REL criteria all pass.

## Acceptance Criteria

### Functional decision correctness

- [ ] **AC-FUN-001:** Exact learned-decision recall is 100% across the evaluation suite.
- [ ] **AC-FUN-002:** Curated supported-paraphrase recall is at least 95%.
- [ ] **AC-FUN-003:** At least 100 cross-domain, cross-operation, cross-project, and option-collision negative cases produce zero learned-rule applications.
- [ ] **AC-FUN-004:** `selectedOption` is always one of the current request options or an explicitly declared policy default.
- [ ] **AC-FUN-005:** Reordering request options does not change a learned or policy-driven decision.
- [ ] **AC-FUN-006:** An unlearned low-risk reversible decision does not automatically personalize the first option.
- [ ] **AC-FUN-007:** A learned choice missing from current options causes an option-change question only for an exact or high-confidence applicable situation; weak matches behave as no match.
- [ ] **AC-FUN-008:** Two close candidates without a sufficient relevance margin return an explicit ambiguous result and ask a focused question.
- [ ] **AC-FUN-009:** Classification priority resolves conflicts only after relevance, scope, and option compatibility.
- [ ] **AC-FUN-010:** A corrected rule cannot outrank a more relevant rule in another scope or decision type solely through its higher priority.
- [ ] **AC-FUN-011:** Confidence is derived from match evidence and is never fixed at 0.92 or 0.97 merely because a learned rule exists.
- [ ] **AC-FUN-012:** A fuzzy match at the minimum application threshold cannot report high confidence.
- [ ] **AC-FUN-013:** Results expose rule ID, scope, match kind, match score, confidence, and causal restrictions.
- [ ] **AC-FUN-014:** The same compiled state and request produce identical substantive results across repeated runs.
- [ ] **AC-FUN-015:** High-risk irreversible, secret-like, and hard-no cases have zero false proceeds.

### Executable policy behavior

- [ ] **AC-POL-001:** The structured Markdown rule format is documented, strictly validated, and preserves wikilinks.
- [ ] **AC-POL-002:** Adding an active valid policy and rebuilding changes an applicable gate result.
- [ ] **AC-POL-003:** Retiring a policy and rebuilding prevents it from applying.
- [ ] **AC-POL-004:** Free prose outside structured rule fields does not silently alter gate behavior.
- [ ] **AC-POL-005:** Invalid control policies fail closed with an actionable error.
- [ ] **AC-POL-006:** Invalid non-control policies are excluded with an actionable compiler warning.
- [ ] **AC-POL-007:** `appliedPolicies` contains only policies that causally influenced the outcome.

### Onboarding and learning

- [ ] **AC-LRN-001:** A clean vault supports a complete interactive onboarding run.
- [ ] **AC-LRN-002:** Onboarding supports a versioned answer file for deterministic automation.
- [ ] **AC-LRN-003:** Onboarding dry-run performs no mutation.
- [ ] **AC-LRN-004:** The user sees an exact policy/update preview before activation.
- [ ] **AC-LRN-005:** Predefined calibration answers compile into executable scoped policies.
- [ ] **AC-LRN-006:** Ambiguous free-text answers remain pending rather than becoming active behavior.
- [ ] **AC-LRN-007:** A non-dry gate ledger entry records options, decision type, scope, selected option, applied rules, match metadata, and outcome.
- [ ] **AC-LRN-008:** Structured feedback can reference a decision ID and explicitly identify chosen and rejected options.
- [ ] **AC-LRN-009:** Applying a correction changes the next applicable result and is idempotent.
- [ ] **AC-LRN-010:** Secret-like onboarding, feedback, ledger, and packet content is rejected or redacted before persistence.

### Host integration

- [ ] **AC-INT-001:** Generic stdio supports the complete structured gate request and response contract.
- [ ] **AC-INT-002:** At least one coding-agent adapter completes gate, record, correction, preview, approval, and changed-next-decision flow.
- [ ] **AC-INT-003:** MCP exposes allowlisted gate, context, record, feedback, pending-preview, and approved-apply tools with no shell tool.
- [ ] **AC-INT-004:** Pre-tool hooks enforce safety and approval decisions without claiming to infer personal choices they cannot observe.
- [ ] **AC-INT-005:** Every adapter advertises `enforced`, `best-effort`, or `instruction-only` accurately.
- [ ] **AC-INT-006:** Integration doctor verifies executable, vault, configuration, gate, recording, feedback, and enforcement status.
- [ ] **AC-INT-007:** Installer dry-run lists every planned change.
- [ ] **AC-INT-008:** Installer mutation backs up changed existing files, is idempotent, and refuses unmanaged owned-file replacement.
- [ ] **AC-INT-009:** Golden-payload tests cover every advertised host event shape.

### Durability and recovery

- [ ] **AC-DUR-001:** Concurrent identical requests cannot generate duplicate IDs.
- [ ] **AC-DUR-002:** Atomic writes use unique same-directory temporary files and sync written data before replacement.
- [ ] **AC-DUR-003:** JSONL appends are process-safe and never interleave partial JSON values.
- [ ] **AC-DUR-004:** Update application is serialized and cannot apply the same packet twice.
- [ ] **AC-DUR-005:** Index rebuild, snapshot, restore, ledger, capture, and update operations use appropriate process-level locking.
- [ ] **AC-DUR-006:** Stale locks are detectable and recoverable without removing active locks.
- [ ] **AC-DUR-007:** A 16-process concurrency test produces complete valid state with unique IDs and no lost records.
- [ ] **AC-DUR-008:** Restore validates content, index, links, and gate behavior in staging before replacing the target.
- [ ] **AC-DUR-009:** Failure injection at every restore phase leaves either the previous complete vault or the restored complete vault active.
- [ ] **AC-DUR-010:** Export and restore preserve exact learned, corrected, and policy-driven behavior.

### Security and privacy

- [ ] **AC-SEC-001:** `cargo audit` reports no unignored vulnerabilities.
- [ ] **AC-SEC-002:** `cargo deny check` passes advisories, bans, licenses, and sources.
- [ ] **AC-SEC-003:** The known affected `crossbeam-epoch` version is upgraded to a patched release.
- [ ] **AC-SEC-004:** The web UI rejects non-loopback binding by default.
- [ ] **AC-SEC-005:** Web requests have bounded size and read/write timeouts.
- [ ] **AC-SEC-006:** Read-only web and search output cannot expose notes classified as secret.
- [ ] **AC-SEC-007:** Import, restore, update packets, identifiers, and archive paths retain traversal, portability, schema, and secret validation.
- [ ] **AC-SEC-008:** An SBOM is generated and retained for the release artifact.

### Performance and deterministic operation

- [ ] **AC-PERF-001:** Gate evaluation performs no network, LLM, AgentMemory, embedding generation, external provider, runtime download, runtime model load, or full-vault scan.
- [ ] **AC-PERF-002:** Candidate terms and rows remain explicitly bounded and covered by tests.
- [ ] **AC-PERF-003:** Optimized 1k-note gate latency is below 10 ms p95 on the reference release host.
- [ ] **AC-PERF-004:** Optimized 5k-note gate latency is below 25 ms p95 on the reference release host.
- [ ] **AC-PERF-005:** A 5k-note index rebuild completes below 1 second on the reference release host.
- [ ] **AC-PERF-006:** Performance results are recorded with host details and are treated as release baselines, not universal hardware guarantees.

### Whole-program release acceptance

- [ ] **AC-REL-001:** All unit, interface, integration, adapter, evaluation, property, concurrency, fault, and smoke tests pass.
- [ ] **AC-REL-002:** Formatting check passes.
- [ ] **AC-REL-003:** Clippy passes for all targets and features with warnings denied.
- [ ] **AC-REL-004:** Locked optimized `brainmap` and `brainmapd` builds pass.
- [ ] **AC-REL-005:** Cargo and npm package smoke tests pass.
- [ ] **AC-REL-006:** Export checksum and restore drills pass using the release binary.
- [ ] **AC-REL-007:** Linux 1k and 5k scale drills pass using the release binary.
- [ ] **AC-REL-008:** CI covers Linux, macOS, and Windows for supported behavior.
- [ ] **AC-REL-009:** A 1-2 week local shadow-mode dogfood run records no safety false-proceed and no confirmed cross-domain learned-rule application.
- [ ] **AC-REL-010:** Shadow-mode aggregate metrics include exact/fuzzy match rate, agreement, correction, false ask, collision, match margin, and latency without retaining raw prompts for metrics.
- [ ] **AC-REL-011:** User documentation accurately states supported scope, enforcement levels, performance envelope, backup procedure, and known non-goals.
- [ ] **AC-REL-012:** The final verification leaves the repository worktree clean.

## Definition of Done

This milestone is complete only when:

1. Every acceptance criterion above is checked and backed by current evidence.
2. FIA-1 through FIA-8 pass against an optimized release binary.
3. No required work is deferred as a known blocker.
4. The documented product claim is limited to a single-user, completely local decision engine for individual developers.
5. A fresh developer can complete onboarding, teach a decision, receive the intended result, correct it, use it through a supported host, and restore it from backup without consulting repository internals.

Passing the existing test suite alone is not sufficient for completion.

## Qualification Decisions

1. Fuzzy matching uses deterministic symmetric token Jaccard with a `0.75` minimum, a `0.10` ambiguity margin, scope/type compatibility, operation/domain anchors, option compatibility, and actual-rule relevance before classification priority. Final release evidence must retain the measured recall/collision trade-off.
2. Codex is the selected M001 host adapter. Its observable pre-tool safety/approval boundary is `enforced`, MCP is `best-effort`, and skill/project instructions are `instruction-only`. FIA-5 and real-use dogfood remain required before calling it fully proven.
3. Non-loopback web binding is rejected in this milestone; no remote-access escape hatch is claimed.
4. Uncertain free-text onboarding remains pending. Only constrained predefined answers compile, with exact preview and explicit approval.
